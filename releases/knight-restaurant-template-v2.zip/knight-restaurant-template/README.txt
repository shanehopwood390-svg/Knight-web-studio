KNIGHT RESTAURANT WEBSITE TEMPLATE — VERSION 2

FILES
- index.html: editable restaurant template and browser preview
- README.txt: this guide

HOW TO USE
1. Open index.html in a modern web browser.
2. Edit the restaurant information and menu in the editor.
3. Select Update Website Preview.
4. Select Download My Website to create a customized HTML website.
5. Open the downloaded HTML file to check it before publishing.

IMPORTANT
- The exported website is a standalone HTML file.
- Publishing online requires a separate hosting service.
- Check all business details, prices, contact information and permissions before publishing.
- This package does not include a paid checkout or automatic hosting.
